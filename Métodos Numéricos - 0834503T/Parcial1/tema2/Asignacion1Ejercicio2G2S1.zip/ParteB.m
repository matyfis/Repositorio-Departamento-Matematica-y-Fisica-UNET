%Parte B del problema, encontrar la altura minima
%------------------------------------------------
%Usamos metodos de la secante
%Inicializamos y definimos variables
%-----------------------------------

%valores de los intervalos para hallar Altura
yA= 10;
yB= 11;

%variables del ejercicio planteado
w = 10;% <----- Peso
yO = 5; % <---- y sub-zero
y_target = 15;% <---- Altura maxima Y
x_target = 50; % <----- Distancia X 

%función g(x) <---- De aqui sacamos la grafica
g = @(x) (TA_solution/w)*cosh(w*x/TA_solution) + yO - (TA_solution/w);
%función j(x) <---- De aqui hallamos la Altura Minima
j = @(y0) (TA_solution/w)*cosh(w*x_target/TA_solution) + y0 - (TA_solution/w) - y_target;
%tolerancia
tol = 0.00001;
%Numero de iteraciones maxima
itmax = 100;

%tabla de resultados
%-------------------
fprintf('\n iteracción \t Altura Minima y0 \t Error Abs.(Ea)');

%Función Secante:
%Cuando llamamos la función, nos imprime resultados
%requisitos: colocar las variables que solicita en
% secanteF(variable1,variable2,variable3,variable4,variable5)
[rA,iter] = secanteF(yA,yB,j,tol,itmax);
%------------------------------------------------------------

%Graficación de la funcion g(x)
z=-50:0.01:50; % <----- coordenadas
plot(z,g(z)) % <----- función o metodo para graficar g(x)
grid  % <----- Activamos la grilla del plano cartesiano
xlabel('x') % <---- para colocar 'x' en el eje de las x
ylabel('g(x)') % <---- para colocar 'g(x)' en ee eje de las y
title('Function g') % <---- para añadirle un titulo