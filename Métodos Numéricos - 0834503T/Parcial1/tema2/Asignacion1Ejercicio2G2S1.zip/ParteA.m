%Ejercicio Nro 2
%Usamos metodo de la secante
%Parte A del problema, encontrar la TA
%------------------------------------------------

%Inicializamos y definimos variables
%-----------------------------------
%variables del ejercicio planteado
w = 10;% <----- Peso
y_target = 15;% <---- Altura maxima Y
x_target = 50;% <---- Distancia X
yO = 5; % <---- y sub-zero 

%valores de los intervalos para hallar TA
x1 = 10;
x2 = 11;
%función u(x) <---- De aqui hallamos TA
u = @(TA) (TA/w)*cosh(w*x_target/TA) + yO - (TA/w) - y_target;
%tolerancia
tol = 0.00001;
%Numero de iteraciones maxima
itmax = 100;

%tabla de resultados
%-------------------
fprintf('\n iteracción \t TA \t Error Abs.(Ea)');

%Función Secante:
%Cuando llamamos la función, nos imprime resultados
%requisitos: colocar las variables que solicita en
% secanteF(variable1,variable2,variable3,variable4,variable5)
[TA_solution,iter] = secanteF(x1,x2,u,tol,itmax);
%------------------------------------------------------------

