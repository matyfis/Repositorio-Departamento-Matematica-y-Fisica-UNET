%Función Secante
%declaramos la función secante y la convertimos en un metodo
function [r,iter] = secanteF(x1,x2,f,tol,itmax)

%Inicializamos y definimos variables
%-----------------------------------
errorP= 1; % <----- Declaramos el Error Abs
iter=0; % <----- Declaramos e inicializamos las iteraciones

%estructura de la funcion Secante
%--------------------------------
while errorP > tol && iter < itmax

%Aproximamos la raiz con la fórmula correspondiente
r=x2-(f(x2)*(x1-x2))/(f(x1)-f(x2));

%Calculamos el porcentaje de error 
errorP = abs(((r-x2)/r)*100);

x1=x2; % <----- igualamos x1 y x2
x2=r; % <----- y luego lo igualamos r para obtener los resultados 
iter=iter+1; % <----- creamos el contador de iteraciones
fprintf('\n %0.2f \t %0.4f \t %0.4f',iter,r,errorP);
end

